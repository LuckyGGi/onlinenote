<?php
    require 'forma/app/src/app.php';  ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="PHP forma">
        <title>Contacts</title>
        <link rel="stylesheet" href="forma/app/css/style.css">
        
    </head>
    <body>
    <?php include('partials/header.php');
        include('forma/app/views/content.php');
        include('partials/footer.php');
        ?>
  
        
        