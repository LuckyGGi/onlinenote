<main>
<div class="container">
<form id="contact" action="contacts.php" method="post">
<h3>Let's talk</h3>
<h4>contact form</h4>
<p><input type="text" name="name" placeholder="Your name" required autofocus></p>
<p><input type="email" name="email" placeholder="Your email" required></p>
<p><textarea placeholder="Your mesage..." name="message" required></textarea></p>
<p><button name="submit" type="submit" id="contact-submit">Send</button></p>
</form>
</div>
</main>