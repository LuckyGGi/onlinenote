<?php
    define("DB_SERVER", "localhost");
    define("DB_USER", "root");
    define("DB_PASSWORD", '');
    define("DB_NAME", 'note2');


        $mysqli = new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_NAME);
        if($mysqli->connect_error) {
            echo "Atsiprašome, bet svetainė susidūrė su problema.\n";
            echo 'Klaida ' . $mysqli->connet_error . '\n';
            exit();
        }

        mysqli_query($mysqli, "INSERT INTO forma1 (vardas, email, message) 
        VALUES('$_POST[name]', '$_POST[email]' , '$_POST[message]')");
   
    ?>