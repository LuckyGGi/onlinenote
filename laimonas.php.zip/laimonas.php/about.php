<head>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>About-me</title>
		<link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">   
    <link rel="stylesheet" href="forma/app/css/style.css">
</head>
<body>
<?php include('partials/header.php');?>
<!--<h2>About-me</h2>-->
<div class="container" > <h2>Hello, I am junior java and full-stack web developer 
        with marketing backgroud in marketing strategy, media planing and buying.
        At the moment my focus on E-comercial and web soliutions,
        mobile apps creation, digital marketing and ads administration services
        My greatest passion is to travel. 
        Make note on my online app  and Let's talk or work on your project together! <a href="contacts.php" class="nav-link">Contact</a></li> </h2>
</div>
<header class="about-me-header">
            <div class="container">
            </div>
        </header>
        <section class="about-me">
            <div class="container flex-container">
                </div>
                <div class="me">
                    <img src="img/me.jpg" alt="LuckyGGI">
                </div>
            </div>
        </section>
<?php
include'partials/footer.php';
?>
</body>
</html>
