<?php include_once("config/db.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport"content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>My Online notes</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="forma/app/css/style.css">
       
</head>
<body>
    <?php include "partials/header.php";?>
  <div class="container">
    <h2 class="text-align:center">New Note</h2>
      <form action="partials/add.php" method="post">
    <div class="form-row">
            <div class="col">
                  <div class="form-group">
                      <label for="name">Note</label>
                      <input type="text" class="form-control" name="name" placeholder="type text...">
                  </div>
            </div>
              <div class="col">
                  <div class="form-group">
                      <label for="date">Date</label>
                      <input type="date" class="form-control" name="date" placeholder="Enter date">
                  </div>
              </div>
              <div class="form-group">
                <input value="Submit" title="Submit" type="submit" id="btn_lg" name="submit">
              </div>
    </div>
    </form>
    
</div>    
        <table class="container table text-white bg-dark">
          <div>
             <th>Note</th>
              <th>Date</th>
              </div>
          <tbody>
              <?php
              $sql = "SELECT * FROM note";
              $result = mysqli_query($conn, $sql);
              
              if($result){
                  if(mysqli_num_rows($result) > 0){
                      while($row = mysqli_fetch_assoc($result)){ ?>
                        <tr>
                        <td><?php echo $row['name']; ?></td>
                            <td><?php echo $row['date']; ?></td>
                      </tr>
                              <td>
                                  <a href="#" class="btn btn-danger">done</a>
                              </td>
                          </tr>
                   <?php   }
                  }
                }
            ?>
            
          </tbody> 
      </table>
  </div>
 <?php

include('partials/footer.php');
 
?>
