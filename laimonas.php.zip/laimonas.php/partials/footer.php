<footer>
            <div class="container">
                <p class="copyright">&copy; <?= date('Y'); ?> . Creator LuckyGGi, All rights reserved..</p>
            </div>
        </footer>
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  </body>
  </html>