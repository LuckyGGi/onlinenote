<div class="container">
<div class="navbar navbar-expand-lg navbar-dark bg-dark mb-5">
      <a href="index.php" class="navbar-brand"> <img src="img/LG.jpg"> </a>
      
          <div id="navbarNav">
              <ul class="navbar-nav">
                  <li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
                  <li class="nav-item"><a href="about.php" class="nav-link">About</a></li>
                  <li class="nav-item"><a href="contacts.php" class="nav-link">Contact</a></li>
              </ul>
          </div>
      </div>
      </div>