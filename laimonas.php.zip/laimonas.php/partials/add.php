<?php
require_once('../config/db.php');
    if(isset($_POST['submit'])) {       
        $name = $_POST['name'];
        $date = $_POST['date'];

        $query = "INSERT INTO note (name, date) VALUES('$name', '$date' )";
        mysqli_query($conn, $query);

        header('Location: ../index.php?data_recorded');
}
    ?>